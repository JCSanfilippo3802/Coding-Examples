﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
/// <summary>
/// Jordy Sanfilippo 3/28/2021
/// 
/// This serves as a base class for the other game objects.
/// </summary>
namespace HW3__FirstMonoGameGame
{
    class GameObject
    {
        //Fields
        protected Texture2D texture;
        protected Rectangle position;

        //Properties
        public int X
        {
            get { return position.X; }

            set { position.X = value; }
        }

        public int Y
        {
            get { return position.Y; }

            set { position.Y = value; }
        }

        public Rectangle RectPosition
        {
            get { return position; }
        }

        //Constructor
        public GameObject(Texture2D texture, int X, int Y, int sizeX, int sizeY)
        {
            this.texture = texture;

            Point location = new Point(X, Y);
            Point size = new Point(sizeX, sizeY);
            position = new Rectangle(location, size);
        }

        //Draws the object.
        public virtual void Draw(SpriteBatch sb)
        {
            sb.Draw(texture,position,Color.White);
        }
    }
}
