﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
/// <summary>
/// Jordy Sanfilippo 2/28/2021
/// 
/// This is the player object for the game.
/// </summary>
namespace HW3__FirstMonoGameGame
{
    class Player : GameObject
    {
        //Fields
        private int levelScore;
        private int totalScore;

        //Properties
        public int LevelScore
        {
            get { return levelScore; }
            set { levelScore += value; }
        }

       public int TotalScore
        {
            get { return totalScore; }
            set { totalScore += value; }
        }

        //Constructor
        public Player(Texture2D texture, int X, int Y, int sizeX, int sizeY): base(texture,X,Y,sizeX,sizeY)
        {
            levelScore = 0;
            totalScore = 0;
        }
    }
}
