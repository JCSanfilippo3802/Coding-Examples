﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
/// <summary>
/// Jordy Sanfilippo 2/26/2020
/// 
/// The main logic and declarations for the game project.
/// </summary>
namespace HW3__FirstMonoGameGame
{
    enum GameState
    {
        Game,
        Menu,
        GameOver
    }

    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        //The current state of the game.
        private GameState currentState;

        //Sets variables for all the textures and the game's font.
        private Texture2D collectibleTexture;
        private Texture2D playerTexture;
        private Texture2D menuTexture;
        private SpriteFont textFont;

        //Holds the keyboard states.
        KeyboardState previousKB;
        KeyboardState kb;

        //Miscellanious objects.
        private Player playerObject;
        private List<Collectible> collectibles;
        private int currentLevel;
        private double timer;
        private Random rng = new Random();
        private int activeCollectibles;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            currentState = GameState.Menu;
            timer = 0;
            currentLevel = 0;
            activeCollectibles = 0;
            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            playerTexture = Content.Load<Texture2D>("IdleGirl");
            playerObject = new Player(playerTexture, 0, 0, 50, 55);
            collectibles = new List<Collectible>();
            collectibleTexture = Content.Load<Texture2D>("coin_gold");
            menuTexture = Content.Load<Texture2D>("MenuGirl");
            textFont = Content.Load<SpriteFont>("File");
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            kb = Keyboard.GetState();

            switch (currentState)
            {
                //Handles logic for the Menu state.
                case GameState.Menu:
                    if (SingleKeyPress(Keys.Enter))
                    {
                        currentState = GameState.Game;
                        ResetGame();
                    }
                    if (previousKB.IsKeyDown(Keys.Escape))
                    {
                        this.Exit();
                    }
                    break;

                //Handles logic for he game state.
                case GameState.Game:
                    timer -= gameTime.ElapsedGameTime.TotalSeconds;
                    if(timer <= 0)
                    {
                        currentState = GameState.GameOver;
                    }

                    MovePlayer();
                    ScreenWrap(playerObject);

                    //Adds all the collectibles to their list.
                    for(int i = 0; i < collectibles.Count; i++)
                    {
                        if (collectibles[i].Active)
                        {
                            if (collectibles[i].CheckCollision(playerObject))
                            {
                                if (collectibles[i].AddsTime)
                                {
                                    timer += 2;
                                }
                                activeCollectibles--;
                                playerObject.LevelScore = 1;
                            }
                        }
                        if(activeCollectibles == 0)
                        {
                            playerObject.TotalScore = playerObject.LevelScore;
                            playerObject.LevelScore = 0;
                            NextLevel();
                        }
                    }
                    break;

                //Handles logic for the game over state.
                case GameState.GameOver:
                    if (SingleKeyPress(Keys.Enter))
                    {
                        currentState = GameState.Menu;
                    }
                    break;

                //Brings the finite state machine to the basis if there is none active.
                default:
                    currentState = GameState.Menu;
                    break;
            }

            previousKB = kb;

            base.Update(gameTime);
        }

        //All of this was done March 2nd.
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.RoyalBlue);
            _spriteBatch.Begin();
            switch (currentState)
            {
                //Handles drawing for the Menu state. Adding in the title, art, and a label.
                case GameState.Menu:
                    _spriteBatch.Draw(menuTexture, new Rectangle(new Point(20, _graphics.PreferredBackBufferHeight / 2 - 125), new Point(250, 250)), Color.White);
                    _spriteBatch.DrawString(textFont, "Monopolia", new Vector2(20, _graphics.PreferredBackBufferHeight / 2 + 135), Color.Gold);
                    _spriteBatch.Draw(collectibleTexture, new Rectangle(new Point(_graphics.PreferredBackBufferWidth - 300, _graphics.PreferredBackBufferHeight / 2 - 125), new Point(250, 250)), Color.White);
                    _spriteBatch.DrawString(textFont, "Economy Quest", new Vector2(_graphics.PreferredBackBufferWidth / 2 - 120, _graphics.PreferredBackBufferHeight / 2), Color.Gold);
                    break;

                //Handles drawing while the game is actively running.
                case GameState.Game:
                    playerObject.Draw(_spriteBatch);
                    for(int i = 0; i < collectibles.Count; i++)
                    {
                        collectibles[i].Draw(_spriteBatch);
                    }
                    _spriteBatch.DrawString(textFont, $"Level {currentLevel}", new Vector2(0,0), Color.Gold);
                    _spriteBatch.DrawString(textFont, $"Current Score: {playerObject.LevelScore}", new Vector2(0, 20), Color.Gold);
                    _spriteBatch.DrawString(textFont, String.Format("{0:0.00}", timer), new Vector2(0, 40), Color.Gold);
                    break;

                //Handles drawing during the game over state.
                case GameState.GameOver:
                    _spriteBatch.Draw(menuTexture, new Rectangle(new Point(20, _graphics.PreferredBackBufferHeight / 2 - 200), new Point(400,400)), Color.White);
                    _spriteBatch.DrawString(textFont, "Game Over", new Vector2(_graphics.PreferredBackBufferWidth / 2 + 100, _graphics.PreferredBackBufferHeight / 2 - 20), Color.Gold);
                    _spriteBatch.DrawString(textFont, $"Level {currentLevel}", new Vector2(_graphics.PreferredBackBufferWidth / 2 + 100, _graphics.PreferredBackBufferHeight / 2), Color.Gold);
                    _spriteBatch.DrawString(textFont, $"Total Score: {playerObject.TotalScore}", new Vector2(_graphics.PreferredBackBufferWidth / 2 + 100, _graphics.PreferredBackBufferHeight / 2 + 20), Color.Gold);
                    break;

                //Doesn't draw anything if there is no state.
                default:
                    break;
            }
            base.Draw(gameTime);
            _spriteBatch.End();
        }

        //Prepares the next level for the player once all coins have been collected or the game is reset.
        void NextLevel()
        {
            collectibles.Clear();
            timer = 10.0;

            playerObject.TotalScore = playerObject.LevelScore;
            playerObject.LevelScore = 0;

            playerObject.X = (_graphics.PreferredBackBufferWidth / 2) - playerObject.RectPosition.Width;
            playerObject.Y = (_graphics.PreferredBackBufferHeight / 2) - playerObject.RectPosition.Height;
            for (int i = 0; i < 5 + (3 * currentLevel); i++)
            {
                int collectibleX = rng.Next(0, _graphics.PreferredBackBufferWidth - collectibleTexture.Width);
                int collectibleY = rng.Next(0, _graphics.PreferredBackBufferHeight - collectibleTexture.Height);

                Collectible coin = new Collectible(collectibleTexture, collectibleX, collectibleY, 25, 25);
                if(i > 0 && i%10 == 0)
                {
                    coin.AddsTime = true;
                }

                collectibles.Add(coin);
                activeCollectibles++;
            }
            currentLevel++;
        }

        //Resets the values when the game is begun.
            void ResetGame()
            {
                currentLevel = 0;
                playerObject.TotalScore = 0;
                NextLevel();
            }

        //Brings the player to the opposite side of the screen when they travel too far in one direction.
            void ScreenWrap(GameObject objToWrap)
            {
                if(objToWrap.X >= _graphics.PreferredBackBufferWidth)
                {
                    objToWrap.X = 5;
                }
                if(objToWrap.X <= 0)
                {
                    objToWrap.X = _graphics.PreferredBackBufferWidth - 5;
                }
                if(objToWrap.Y >= _graphics.PreferredBackBufferHeight)
                {
                    objToWrap.Y = 5;
                }
                if(objToWrap.Y <= 0)
                {
                    objToWrap.Y = _graphics.PreferredBackBufferHeight - 5;
                }
            }

        //Checks if a key was pressed a once and was not being held.
            bool SingleKeyPress(Keys key)
            {

                if (kb.IsKeyDown(key) && previousKB.IsKeyUp(key))
                {
                    return true;
                }
                return false;
            }

        //Moves the player around the screen.
            void MovePlayer()
            {
                if(kb.IsKeyDown(Keys.W) || kb.IsKeyDown(Keys.Up))
                {
                    playerObject.Y -= 5;
                }
                if(kb.IsKeyDown(Keys.S) || kb.IsKeyDown(Keys.Down))
                {
                    playerObject.Y += 5;
                }
                if(kb.IsKeyDown(Keys.A) || kb.IsKeyDown(Keys.Left))
                {
                    playerObject.X -= 5;
                }
                if(kb.IsKeyDown(Keys.D) || kb.IsKeyDown(Keys.Right))
                {
                    playerObject.X += 5;
                }
            }
        }
    }

