//JSanfilippo 3/29/2019
public class PlayerObject {
	private String PName;
	private int[] OHits = new int[5];
	
	public PlayerObject(String name, int hits1, int hits2, int hits3, int hits4, int hits5) {
		PName = name;
		OHits[0] = hits1;
		OHits[1] = hits2;
		OHits[2] = hits3;
		OHits[3] = hits4;
		OHits[4] = hits5;
	}
	
	public String getName() {
		return PName;
	}
	
	public String calculateAverage() {
		
		double BatAvg = (double)(OHits[0] + OHits[1] + OHits[2] + OHits[3] + OHits[4])/(double)OHits.length;
		
		String striBatAvg = (PName + ": Batting Average = " + BatAvg);
		return(striBatAvg);
		
	}
}
