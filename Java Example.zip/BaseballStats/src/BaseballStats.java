//JSanfilippo 3/21/2019
import java.awt.*; 
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.util.List;
import java.util.*;

public class BaseballStats extends JFrame implements ActionListener {
		//creates all necessary objects
		JFrame statScreen;
		JTextField nameBox;
		JSpinner statSpinner1;
		JSpinner statSpinner2;
		JSpinner statSpinner3;
		JSpinner statSpinner4;
		JSpinner statSpinner5;
		JTextArea playerTextArea;
		JButton addButton;
		JButton resetButton;
		JButton showButton;
		ArrayList<PlayerObject> playerList = new ArrayList();
		String currentText;
		
	public static void main(String[] args) {
		new BaseballStats();

	}
	
	public BaseballStats() {
		//creates the JFrame and defines parameters
		statScreen = new JFrame();
		statScreen.setTitle("Baseball Stats");
		statScreen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel mainStatPanel = (JPanel)statScreen.getContentPane();
		
		//sets the layout and border
		mainStatPanel.setLayout(new BoxLayout(mainStatPanel, BoxLayout.Y_AXIS));
		Border mainStatBorder = BorderFactory.createEmptyBorder(10, 10, 10, 10);
		mainStatPanel.setBorder(mainStatBorder);
		Border lineBorder = BorderFactory.createLineBorder(Color.PINK, 3);
		
		//creates the box that allows the user to enter the name
		JPanel namePanel = new JPanel();
		JLabel namePrompt = new JLabel("Player Name:");
		nameBox = new JTextField(20);
		
		Border nameTitleBorder = BorderFactory.createTitledBorder(lineBorder, "NAME");
		
		namePanel.add(namePrompt);
		namePanel.add(nameBox);
		namePanel.setBorder(nameTitleBorder);
		
		//adds the name's panel to the main panel
		mainStatPanel.add(namePanel);
		
		//creates the panels to container the hit count spinners
		JPanel statPanelOne = new JPanel();
		JPanel statPanelTwo = new JPanel();
		JPanel statPanelThree = new JPanel();
		JPanel statPanelFour = new JPanel();
		JPanel statPanelFive = new JPanel();
		
		//creates the labels for the hit count spinners
		JLabel spinnerLabel1 = new JLabel("Game 1 Hits:");
		JLabel spinnerLabel2 = new JLabel("Game 2 Hits:");
		JLabel spinnerLabel3 = new JLabel("Game 3 Hits:");
		JLabel spinnerLabel4 = new JLabel("Game 4 Hits:");
		JLabel spinnerLabel5 = new JLabel("Game 5 Hits:");
		
		//creates the hit count spinners
		statSpinner1 = new JSpinner(new SpinnerNumberModel(1,1,10,1));
		statSpinner2 = new JSpinner(new SpinnerNumberModel(1,1,10,1));
		statSpinner3 = new JSpinner(new SpinnerNumberModel(1,1,10,1));
		statSpinner4 = new JSpinner(new SpinnerNumberModel(1,1,10,1));
		statSpinner5 = new JSpinner(new SpinnerNumberModel(1,1,10,1));
		
		//adds the spinners to their respective panels
		statPanelOne.add(spinnerLabel1);
		statPanelOne.add(statSpinner1);
		
		statPanelTwo.add(spinnerLabel2);
		statPanelTwo.add(statSpinner2);
		
		statPanelThree.add(spinnerLabel3);
		statPanelThree.add(statSpinner3);
		
		statPanelFour.add(spinnerLabel4);
		statPanelFour.add(statSpinner4);
		
		statPanelFive.add(spinnerLabel5);
		statPanelFive.add(statSpinner5);
		
		//applies borders to the panels
		statPanelOne.setBorder(lineBorder);
		statPanelTwo.setBorder(lineBorder);
		statPanelThree.setBorder(lineBorder);
		statPanelFour.setBorder(lineBorder);
		statPanelFive.setBorder(lineBorder);
		
		//adds the panels to the main panel
		mainStatPanel.add(statPanelOne);
		mainStatPanel.add(statPanelTwo);
		mainStatPanel.add(statPanelThree);
		mainStatPanel.add(statPanelFour);
		mainStatPanel.add(statPanelFive);
		
		//creates the panel for the players list
		JPanel playersPanel = new JPanel();
		
		//creates the label for the players list
		JLabel playerLabel = new JLabel("Current Players:");
		
		//creates the text area for the players list
		playerTextArea = new JTextArea(5,20);
		
		//makes it so a user can't type in the box
		playerTextArea.setEditable(false);
		
		//creates the scrollpane for the players list
		JScrollPane playerScroll = new JScrollPane(playerTextArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		
		//creates the border for the panel
		Border playerTitleBorder = BorderFactory.createTitledBorder(lineBorder, "PLAYERS");
		
		//adds the components to the panel
		playersPanel.add(playerLabel);
		playersPanel.add(playerScroll);
		
		//sets the panel's border
		playersPanel.setBorder(playerTitleBorder);
		
		//adds the panel to the main panel
		mainStatPanel.add(playersPanel);
		
		JPanel buttonsPanel = new JPanel();
		
		addButton = new JButton("Add Player");
		resetButton = new JButton("Reset Button");
		showButton = new JButton("Show Stats");
		
		addButton.addActionListener(this);
		resetButton.addActionListener(this);
		showButton.addActionListener(this);
		
		buttonsPanel.add(addButton);
		buttonsPanel.add(resetButton);
		buttonsPanel.add(showButton);
		
		mainStatPanel.add(buttonsPanel);
		
		statScreen.pack();
		statScreen.setVisible(true);
	}
	
	public void actionPerformed( ActionEvent event)
	{
		Object button = event.getSource();
		
		if(button == addButton) {
			String name = nameBox.getText();
			int hit1 = (Integer)statSpinner1.getValue();
			int hit2 = (Integer)statSpinner2.getValue();
			int hit3 = (Integer)statSpinner3.getValue();
			int hit4 = (Integer)statSpinner4.getValue();
			int hit5 = (Integer)statSpinner5.getValue();
			
			PlayerObject currentPlayer = new PlayerObject(name, hit1, hit2, hit3, hit4, hit5);
			
			playerList.add(currentPlayer);
			
			nameBox.setText("");
			statSpinner1.setValue(1);
			statSpinner2.setValue(1);
			statSpinner3.setValue(1);
			statSpinner4.setValue(1);
			statSpinner5.setValue(1);
			
			currentText = playerTextArea.getText();
			
			playerTextArea.setText(currentText + currentPlayer.getName() + "\n");
		}
		else if(button == resetButton) {
			nameBox.setText("");
			statSpinner1.setValue(1);
			statSpinner2.setValue(1);
			statSpinner3.setValue(1);
			statSpinner4.setValue(1);
			statSpinner5.setValue(1);
			playerTextArea.setText("");
			currentText = "";
			playerList.clear();
		}
		else {
			String finalMessage = "";
			if(playerList.isEmpty())
				finalMessage = "No stats found\nPlease enter players.";
			else {
				int listLength = playerList.size();
				for(int i = 0; i < listLength; i++)
				{
					finalMessage = (finalMessage + playerList.get(i).calculateAverage() + "\n");
				}
			}
			JOptionPane.showMessageDialog(statScreen, finalMessage);
		}
			
	}

}
