﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
/// <summary>
/// Jordy Sanfilippo 2/28/2021
/// 
/// This is the main collectible class.
/// </summary>
namespace HW3__FirstMonoGameGame
{
    class Collectible : GameObject
    {
        //Fields
        private bool active;
        private bool addsTime;

        //Properties
        public bool Active
        {
            get { return active; }
        }

        public bool AddsTime
        {
            get { return addsTime; }

            set { addsTime = value; }
        }

        //Constructor
        public Collectible(Texture2D texture, int X, int Y, int sizeX, int sizeY) : base(texture, X, Y, sizeX, sizeY)
        {
            active = true;
            addsTime = false;
        }

        //Checks for collision.
        public bool CheckCollision(GameObject check)
        {
            if (this.position.Intersects(check.RectPosition))
            {
                active = false;
                return true;
            }
            return false;
        }

        //Draws the sprite, checking if it adds time or not.
        public override void Draw(SpriteBatch sb)
        {
            if (active)
            {
                if (addsTime)
                {
                    sb.Draw(texture, position, Color.CornflowerBlue);
                    return;
                }
                sb.Draw(texture,position,Color.White);
            }
        }
    }
}
