﻿using System;

namespace HW3__FirstMonoGameGame
{
    public static class Program
    {
        [STAThread]
        static void Main()
        {
            using (var game = new Game1())
                game.Run();
        }
    }
}
